import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { AuthLayout } from "@/components/AuthLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type PersonalInfo = {
  name?: string;
  email?: string;
  message?: string;
};

export default function ProfilePage() {
  const [personalInfo, setPersonalInfo] = useState<PersonalInfo>({
    name: "",
    email: "",
  });
  const [isAuthorized, setIsAuthorized] = useState<boolean | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadProfile() {
      const BASE_URL = "http://localhost:3000";
      setLoading(true);
      setError("");

      try {
        const activateResponse = await fetch(
          `${BASE_URL}/auth/auto-authorization`,
          {
            method: "GET",
            credentials: "include",
          },
        );

        const authData = await activateResponse.json();

        if (activateResponse.status === 401) {
          const refreshResponse = await fetch(`${BASE_URL}/auth/refresh`, {
            method: "POST",
            credentials: "include",
          });

          const refreshData = await refreshResponse.json();

          if (!refreshResponse.ok) {
            setError(refreshData.message);

            return;
          }

          localStorage.setItem('accessToken', refreshData.accessToken);
        }

        localStorage.setItem('accessToken', authData.accessToken);
        const token = localStorage.getItem("accessToken");

        const profileResponse = await fetch(`${BASE_URL}/auth/profile`, {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const profileData = await profileResponse.json();

        if (!profileResponse.ok) {
          setError(profileData.message);

          return;
        }

        setPersonalInfo(profileData);
        setIsAuthorized(true);
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false);
      }
    }

    loadProfile();
  }, []);

  if (isAuthorized === null) {
    return <p className="text-lg font-semibold text-center">Checking authorization...</p>;
  }

  if (!isAuthorized) {
    return (
      <Navigate
        to="/login"
        replace
      />
    );
  }

  return (
    <AuthLayout
      title="Profile Settings"
      description="Manage your personal information and account security."
    >
      <main className="min-h-screen bg-background px-4 py-10 sm:px-6 lg:py-14">
        <div className="mx-auto w-full max-w-2xl space-y-8">
          {loading ? (
            <p className="text-sm text-muted-foreground">Loading profile...</p>
          ) : error ? (
            <p className="text-lg font-semibold text-center">{error}</p>
          ) : (
            <>
              <section className="space-y-5 rounded-xl border bg-card p-5 shadow-sm sm:p-6">
                <h2 className="text-lg font-semibold">Personal Information</h2>

                <div className="space-y-2">
                  <Label>Full Name</Label>
                  <p className="text-sm font-medium">
                    {personalInfo.name || "Not provided"}
                  </p>
                </div>

                <div className="space-y-2">
                  <Label>Current Email Address</Label>
                  <p className="text-sm font-medium">
                    {personalInfo.email || "Not provided"}
                  </p>
                </div>
              </section>

              <section className="space-y-5 rounded-xl border bg-card p-5 shadow-sm sm:p-6">
                <div className="space-y-1">
                  <h2 className="text-lg font-semibold">Change Password</h2>
                  <p className="text-sm text-muted-foreground">
                    Choose a strong password to keep your account secure.
                  </p>
                </div>

                <form className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="current-password">Current Password</Label>
                    <Input
                      id="current-password"
                      name="currentPassword"
                      type="password"
                      placeholder="Enter your current password"
                      autoComplete="current-password"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="new-password">New Password</Label>
                    <Input
                      id="new-password"
                      name="newPassword"
                      type="password"
                      placeholder="Enter a new password"
                      autoComplete="new-password"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">
                      Confirm New Password
                    </Label>
                    <Input
                      id="confirm-password"
                      name="confirmPassword"
                      type="password"
                      placeholder="Confirm your new password"
                      autoComplete="new-password"
                    />
                  </div>

                  <div className="flex justify-end">
                    <Button type="submit">Update Password</Button>
                  </div>
                </form>
              </section>

              <section className="space-y-5 rounded-xl border bg-card p-5 shadow-sm sm:p-6">
                <div className="space-y-1">
                  <h2 className="text-lg font-semibold">
                    Change Email Address
                  </h2>
                  <p className="text-sm text-muted-foreground">
                    Update the email address associated with your account.
                  </p>
                </div>

                <form className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email-password">Current Password</Label>
                    <Input
                      id="email-password"
                      name="currentPassword"
                      type="password"
                      placeholder="Enter your current password"
                      autoComplete="current-password"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="new-email">New Email Address</Label>
                    <Input
                      id="new-email"
                      name="newEmail"
                      type="email"
                      placeholder="Enter your new email address"
                      autoComplete="email"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="confirm-email">
                      Confirm New Email Address
                    </Label>
                    <Input
                      id="confirm-email"
                      name="confirmEmail"
                      type="email"
                      placeholder="Confirm your new email address"
                      autoComplete="email"
                    />
                  </div>

                  <div className="rounded-lg border bg-muted/50 p-4">
                    <p className="text-sm leading-6 text-muted-foreground">
                      A confirmation link will be sent to your new email
                      address. We will also notify your current email address
                      about this change.
                    </p>
                  </div>

                  <div className="flex justify-end">
                    <Button type="submit">Update Email Address</Button>
                  </div>
                </form>
              </section>

              <section className="rounded-xl border border-destructive/30 bg-card p-5 shadow-sm sm:p-6">
                <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                  <div className="space-y-1">
                    <h2 className="text-lg font-semibold">Log Out</h2>
                    <p className="text-sm text-muted-foreground">
                      Sign out of your account on this device.
                    </p>
                  </div>

                  <Button variant="destructive" type="button">
                    Log Out
                  </Button>
                </div>
              </section>
            </>
          )}
        </div>
      </main>
    </AuthLayout>
  );
}
