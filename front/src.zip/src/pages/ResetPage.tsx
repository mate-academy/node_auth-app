
import { useState } from "react";
import { Link } from "react-router-dom";
import { AuthLayout } from "@/components/AuthLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function ResetPage() {
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    // TODO: connect to Express API
    setSubmitted(true);
  }

  return (
    <AuthLayout
      title="Reset your password"
      description="We'll send you a link to reset your password"
    >
      {submitted ? (
        <div className="space-y-5">
          <p className="text-center text-sm leading-relaxed text-black/60">
            If an account exists for this email, you will receive
            instructions to reset your password.
          </p>

          <Link
            to="/login"
            className="flex h-12 w-full items-center justify-center rounded-xl bg-black px-4 text-sm font-medium text-white transition hover:bg-black/85"
          >
            Back to login
          </Link>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="email">Email address</Label>
            <Input
              id="email"
              name="email"
              type="email"
              placeholder="email@example.com"
              autoComplete="email"
              required
              className="h-12 rounded-xl border-black/10 bg-white/70"
            />
          </div>

          <Button
            type="submit"
            className="h-12 w-full rounded-xl bg-black text-white hover:bg-black/85"
          >
            Send reset link
          </Button>

          <p className="text-center text-sm text-black/60">
            Remember your password?{" "}
            <Link
              to="/login"
              className="font-medium text-black underline underline-offset-4"
            >
              Log in
            </Link>
          </p>
        </form>
      )}
    </AuthLayout>
  );
}
